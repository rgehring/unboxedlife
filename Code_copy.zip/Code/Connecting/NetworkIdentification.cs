using Sandbox;

namespace UnboxedLife;

public sealed class NetworkIdentification : Component
{
	/*[Property] public string TagToApply { get; set; } = "player";

	protected override void OnStart()
	{
		if ( !string.IsNullOrWhiteSpace( TagToApply ) )
		{
			// Apply to the root so traces hitting any child can still be treated as "player"
			GameObject.Root.Tags.Add( TagToApply );
		}
	}
	*/
}
